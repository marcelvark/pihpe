<?
   /* -------------------------------------------------------------------------
      Associate resource URLs with a unique name (URN) here.
   */

   $paths = [
      'section'    => '/section.php',
      'layout'     => '/_php/layout.php'
   ];
?>