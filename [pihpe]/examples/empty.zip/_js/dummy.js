/*
   This is just an example for PiHPe's links() function. 
*/