<?
   /* -------------------------------------------------------------------------
      Associate resource URLs with a unique name (URN) here.
   */

   $paths = [
      'section'    => '/section.php',
      'build'      => '/[pihpe]/build.php',
      'layout'     => '/_php/layout.php',
      'favicon'    => '/_images/favicon.png',
      'apple-icon' => '/_images/apple-touch-icon.png'
   ];
?>