# PiHPe

*Love to play with HTML and CSS, and ready to learn some PHP?*

PiHPe can help you build simple websites. Here's an [example](https://marcelvark.github.io/) that explains what it does, and how to use it. All files used are in the repository. You'll need to install PHP from [php.net](http://php.net) too, and may want to edit my `serve.cmd`. But then you're ready to go.

Some additional features are planned for PiHPe:
- adding file-relative linking
- creating a simple template facility
